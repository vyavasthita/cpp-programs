/* Dynamic loaded CORBA Modules
 *  Copyright (c) 2002 Sorin Mustaca
 *
 *  For more information, visit the Personal Home Page at
 *  http://come.to/sorin-mustaca
 */

// NTService.h

#include <windows.h>
#include <stdio.h>
#include "ntservice.h"
