#include <mico/version.h>

char *version_string = "mico-" MICO_VERSION;
